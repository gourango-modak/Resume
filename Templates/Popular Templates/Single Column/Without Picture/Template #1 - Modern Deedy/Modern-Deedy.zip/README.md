This is just a template, I encourage you to modify it if you don't like how something looks. For example,  you can change the fonts to something you like better. Or, add bullet points to the project section.

GitHu: https://github.com/Aarif123456/modern-deedy